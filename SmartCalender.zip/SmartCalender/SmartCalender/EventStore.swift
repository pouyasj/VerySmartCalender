//
//  EventStore.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 11/11/25.
//

import Foundation
import Combine

final class EventStore: ObservableObject {
    @Published private(set) var eventsByDay: [Date: [Event]] = [:]
    private let cal = Calendar.current

    private func dayKey(_ date: Date) -> Date {
        let c = cal.dateComponents([.year,.month,.day], from: date)
        return cal.date(from: c) ?? date
    }

    func addEvent(_ event: Event) {
        let key = dayKey(event.date)
        var arr = eventsByDay[key] ?? []
        arr.append(event)
        arr.sort { ($0.date, $0.title) < ($1.date, $1.title) }
        eventsByDay[key] = arr
    }

    func events(on date: Date) -> [Event] {
        eventsByDay[dayKey(date)] ?? []
    }

    func hasEvents(on date: Date) -> Bool {
        !(eventsByDay[dayKey(date)] ?? []).isEmpty
    }
}
