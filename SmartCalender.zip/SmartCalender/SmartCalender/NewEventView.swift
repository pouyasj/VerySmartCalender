//
//  NewEventView.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 11/11/25.
//

import SwiftUI

struct NewEventView: View {
    @EnvironmentObject var eventStore: EventStore
    @Environment(\.dismiss) private var dismiss
    
    
    @State private var selectedSegment: Int = 0  // 0 = Event, 1 = Reminder
    @State private var smartInput: String = ""
    @State private var title: String = ""
    @State private var location: String = ""
    @State private var isAllDay: Bool = false
    @State private var startDate: Date
    @State private var endDate: Date
    
    // default date from MonthView
    init(defaultDate: Date) {
        _startDate = State(initialValue: defaultDate)
        _endDate = State(initialValue: defaultDate.addingTimeInterval(60 * 60)) // +1h
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            ScrollView{
            VStack(spacing: 16) {
                
                // Handle + Top bar
                VStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.gray.opacity(0.5))
                        .frame(width: 40, height: 4)
                    
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            ZStack {
                                Circle()
                                    .fill(Color.black.opacity(0.7))
                                Image(systemName: "xmark")
                                    .foregroundColor(.white)
                                    .font(.system(size: 16, weight: .semibold))
                            }
                            .frame(width: 36, height: 36)
                        }
                        
                        Spacer()
                        
                        Text("New")
                            .foregroundColor(.white)
                            .font(.system(size: 20, weight: .semibold))
                        
                        Spacer()
                        

                        Button {
                            saveEvent()
                        } label: {
                            ZStack {
                                Circle()
                                    .fill(Color.blue)
                                Image(systemName: "checkmark")
                                    .foregroundColor(.white)
                                    .font(.system(size: 18, weight: .bold))
                            }
                            .frame(width: 40, height: 40)
                        }
                    }
                    .padding(.horizontal, 16)
                }
                .padding(.top, 8)
                
                HStack(spacing: 0) {
                    segmentButton(title: "Event", index: 0)
                    segmentButton(title: "Reminder", index: 1)
                }
                .background(Color.gray.opacity(0.35))
                .clipShape(Capsule())
                .padding(.horizontal, 16)
                
                // Smart fucking Input box
                VStack(alignment: .leading) {
                    TextEditor(text: $smartInput)
                        .scrollContentBackground(.hidden)
                        .foregroundColor(.white)
                        .font(.system(size: 16))
                        .frame(minHeight: 140, alignment: .topLeading)
                        .padding(10)
                        .background(Color(red: 0.16, green: 0.16, blue: 0.18))
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(
                            Group {
                                if smartInput.isEmpty {
                                    Text("Smart Input")
                                        .foregroundColor(.gray)
                                        .padding(.horizontal, 18)
                                        .padding(.vertical, 14)
                                        .allowsHitTesting(false)
                                }
                            },
                            alignment: .topLeading
                        )
                }
                .padding(.horizontal, 16)
                
                Rectangle()
                    .fill(Color.gray.opacity(0.4))
                    .frame(height: 1)
                    .padding(.horizontal, 16)
                
                VStack(alignment: .leading, spacing: 8) {
                    TextField("Title", text: $title)
                        .foregroundColor(.gray)
                        .font(.system(size: 17))
                        .padding(.vertical, 6)
                        .overlay(Rectangle().fill(Color.gray.opacity(0.4)).frame(height: 1), alignment: .bottom)
                    
                    TextField("Location", text: $location)
                        .foregroundColor(.gray)
                        .font(.system(size: 15))
                        .padding(.vertical, 6)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color(red: 0.16, green: 0.16, blue: 0.18))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .padding(.horizontal, 16)
                
                VStack(spacing: 0) {
                    HStack {
                        Text("All-day")
                            .foregroundColor(.white)
                        Spacer()
                        Toggle("", isOn: $isAllDay)
                            .labelsHidden()
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    
                    Divider().background(Color.gray.opacity(0.4))
                    
                    HStack {
                        Text("Starts")
                            .foregroundColor(.gray)
                        Spacer()
                        DatePicker("", selection: $startDate, displayedComponents: isAllDay ? [.date] : [.date, .hourAndMinute])
                            .labelsHidden()
                            .colorScheme(.dark)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    
                    HStack {
                        Text("Ends")
                            .foregroundColor(.gray)
                        Spacer()
                        DatePicker("", selection: $endDate, displayedComponents: isAllDay ? [.date] : [.date, .hourAndMinute])
                            .labelsHidden()
                            .colorScheme(.dark)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    
                    Divider().background(Color.gray.opacity(0.4))
                    
                    HStack {
                        Text("Travel Time")
                            .foregroundColor(.gray)
                        Spacer()
                        Text("None ▾")
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                }
                .background(Color(red: 0.16, green: 0.16, blue: 0.18))
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .padding(.horizontal, 16)
                
                Spacer()
            }
            .padding(.bottom, 40)
            }
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .presentationDetents([.large])
        .presentationDragIndicator(.hidden)
    }
    
    // MARK: - Segmented button
    
    private func segmentButton(title: String, index: Int) -> some View {
        Button {
            selectedSegment = index
        } label: {
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(selectedSegment == index ? .white : .gray)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(
                    Group {
                        if selectedSegment == index {
                            RoundedRectangle(cornerRadius: 18)
                                .fill(Color.white.opacity(0.16))
                        } else {
                            Color.clear
                        }
                    }
                )
        }
    }
    
    // MARK: - Save
    
    private func saveEvent() {
        let baseDay = startDate
        
        if !smartInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           let parsed = SmartParser.parse(smartInput, baseDay: baseDay) {
            
            let event = Event(title: parsed.title,
                              date: parsed.start,
                              end: parsed.end,
                              location: parsed.location)
            eventStore.addEvent(event)
            dismiss()
            return
        }
        

        let trimmed = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { dismiss(); return }
        let event = Event(title: trimmed, date: startDate, end: isAllDay ? nil : endDate, location: location.isEmpty ? nil : location)
        eventStore.addEvent(event)
        dismiss()
    }
}
