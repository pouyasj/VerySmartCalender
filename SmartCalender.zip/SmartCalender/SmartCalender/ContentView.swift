//
//  ContentView.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 09/11/25.
//

import SwiftUI

private let monthColumns: [GridItem] = Array(repeating: GridItem(.flexible(), spacing: 24), count: 3)

private let monthNames = ["Jan", "Feb", "Mar",
                          "Apr", "May", "Jun",
                          "Jul", "Aug", "Sep",
                          "Oct", "Nov", "Dec"]
struct ContentView: View {
    @EnvironmentObject var eventStore: EventStore
    @State private var showingNewEvent = false
    @State private var isSearching = false
    @State private var searchText = ""
    @FocusState private var searchFocused: Bool

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                
                Color.black
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 0) {
                   
                    
                    Text("2025")
                        .font(.system(size: 48, weight: .thin))
                        .foregroundColor(.red)
                        .padding(.horizontal, 24)
                    

                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.2))
                        .padding(.top, 12)
                        .padding(.horizontal, 24)
                    LazyVGrid(columns: monthColumns, alignment: .leading, spacing: 24) {
                        ForEach(1...12, id: \.self) { month in
                            NavigationLink {
                                MonthView(month: month, year: 2025)
                            } label: {
                                YearMonthView(
                                    month: month,
                                    year: 2025,
                                    isHighlighted: month == 11
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    .padding(.top, 16)
                    .padding(.horizontal, 24)

                    Spacer()
                }
                
                HStack {
                    
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
                
            }
            

            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    if !isSearching {
                        Button {
                            withAnimation(.spring(response: 0.25, dampingFraction: 0.85)) {
                                isSearching = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                                searchFocused = true
                            }
                        } label: {
                            Image(systemName: "magnifyingglass")
                        }

                        Button("Add", systemImage: "plus") {
                            showingNewEvent = true
                        }
                    }
                }
            }
            
            .toolbar {
                ToolbarItemGroup(placement: .bottomBar) {
                    Button("Today") {
                    }
                    .controlSize(.small)
                    Spacer(minLength: 0)
                }
            }
            .sheet(isPresented: $showingNewEvent) {
                let defaultDate = Calendar.current.date(from: DateComponents(year: 2025, month: 1, day: 1)) ?? Date()
                NewEventView(defaultDate: defaultDate)
                    .environmentObject(eventStore)
            }
            .safeAreaInset(edge: .top)  {
                if isSearching {
                    VStack(spacing: 8)
                    {
                        // fuckin Searchhh
                        HStack(spacing: 10) {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.gray)

                            TextField("Search", text: $searchText)
                                .textInputAutocapitalization(.never)
                                .disableAutocorrection(true)
                                .foregroundColor(.white)
                                .focused($searchFocused)

                            Image(systemName: "mic")
                                .foregroundColor(.gray)
                            Button {
                                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                                    searchText = ""
                                    isSearching = false
                                }
                                searchFocused = false
                                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder),
                            to: nil, from: nil, for: nil)
                            } label: {
                                ZStack {
                                    Circle()
                                        .fill(.ultraThinMaterial)
                                        .overlay(
                                            Circle().stroke(Color.white.opacity(0.18), lineWidth: 1)
                                                )
                                    Image(systemName: "xmark")
                                        .foregroundColor(.white)
                                        .font(.system(size: 14, weight: .semibold))
                                }
                                .frame(width: 32, height: 32)
                            }
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(
                            RoundedRectangle(cornerRadius: 22)
                                .fill(Color.white.opacity(0.08))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 22)
                                        .stroke(Color.white.opacity(0.12), lineWidth: 1)
                                )
                        )
                        .padding(.horizontal, 16)
                        .padding(.top, 6)
                        Rectangle()
                            .fill(Color.white.opacity(0.12))
                            .frame(height: 1)
                            .padding(.horizontal, 0)
                    }
                    .background(.thinMaterial)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            }
        }
    }

#Preview {
    ContentView()
        .environmentObject(EventStore())
}

struct YearMonthView: View {
    let month: Int
    let year: Int
    let isHighlighted: Bool
    
    private let calendar = Calendar.current
    private let dayColumns: [GridItem] = Array(
        repeating: GridItem(.flexible(), spacing: 0),
        count: 7
    )
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(monthName)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(isHighlighted ? Color(red: 1.0, green: 0.23, blue: 0.18) : .white)
            
            LazyVGrid(columns: dayColumns, spacing: 2) {
                ForEach(daySlots, id: \.self) { value in
                    if let day = value {
                        Text("\(day)")
                            .font(.system(size: 10, weight: .regular, design: .default))
                            .foregroundColor(isHighlighted ? .white : .gray)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    } else {
                        Text(" ")
                            .font(.system(size: 10))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
    }
    
    private var monthName: String {
        calendar.shortMonthSymbols[month - 1]
    }
    
    private var daySlots: [Int?] {
        var slots: [Int?] = []
        
        let components = DateComponents(year: year, month: month, day: 1)
        guard let firstDay = calendar.date(from: components),
              let range = calendar.range(of: .day, in: .month, for: firstDay)
        else { return [] }
        
        let firstWeekday = calendar.component(.weekday, from: firstDay)
        let leadingEmpty = (firstWeekday - calendar.firstWeekday + 7) % 7
        
        slots.append(contentsOf: Array(repeating: nil, count: leadingEmpty))
        for day in range {
            slots.append(day)
        }
        
        return slots
    }
}

struct MonthView: View {
    let month: Int
    let year: Int
    
    @EnvironmentObject var eventStore: EventStore  
    @State private var selectedDay: Int?
    @State private var showingNewEvent = false
    
    private var calendar: Calendar {
        var c = Calendar.current
        c.firstWeekday = 2      // 1 = Sunday, 2 = Monday
        return c
    }

    private let dayColumns: [GridItem] = Array(
        repeating: GridItem(.flexible(), spacing: 0),
        count: 7
    )
    private var selectedDate: Date {
        calendar.date(from: DateComponents(
            year: year, month: month, day: selectedDay ?? 1
        )) ?? Date()
    }

    private var itemsForSelectedDay: [Event] {
        eventStore.events(on: selectedDate)
    }

    private func timeHHmm(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: d)
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
                .toolbar {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button("Today") {
                        }
                        .controlSize(.small)
                        Spacer(minLength: 0)
                    }
                }
                .toolbar {
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button("Search", systemImage: "magnifyingglass") {
                            showingNewEvent = true
                        }
                        Button("Add", systemImage: "plus") {
                            showingNewEvent = true
                        }

                    }
                }
                .sheet(isPresented: $showingNewEvent) {
                    let defaultDate: Date = {
                        if let day = selectedDay,
                           let d = calendar.date(from: DateComponents(year: year, month: month, day: day)) {
                            return d
                        }
                        return calendar.date(from: DateComponents(year: year, month: month, day: 1)) ?? Date()
                    }()

                    NewEventView(defaultDate: defaultDate)
                        .environmentObject(eventStore)
                }


            VStack(alignment: .leading, spacing: 0) {
                
                Text(monthName)
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 16)
                    .padding(.horizontal, 24)
                
                HStack {
                    ForEach(weekdays, id: \.self) { symbol in
                        Text(symbol)
                            .font(.system(size: 11, weight: .regular))
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity)
                    }
                }
                .padding(.top, 8)
                .padding(.horizontal, 24)
                
                LazyVGrid(columns: dayColumns, spacing: 16) {
                    ForEach(daySlots, id: \.self) { value in
                        if let day = value {
                            let date = calendar.date(from: DateComponents(year: year, month: month, day: day))!
                            let isToday = calendar.isDateInToday(date)
                            let isSelected = selectedDay == day
                            let hasDot = eventStore.hasEvents(on: date)

                            ZStack {
                                if isToday {
                                    Circle().fill(Color.red).frame(width: 28, height: 28)
                                } else if isSelected {
                                    Circle().fill(Color.white).frame(width: 28, height: 28)
                                }

                                VStack(spacing: 0) {
                                    Text("\(day)")
                                        .font(.system(size: 17, weight: .regular))
                                        .foregroundColor(isToday ? .black : (isSelected ? .black : .white))

                                    if hasDot {
                                        Circle()
                                            .fill(Color.purple)
                                            .frame(width: 6, height: 6)
                                            .opacity(isSelected ? 0.9 : 1.0)
                                    } else {
                                        Color.clear.frame(width: 6, height: 6)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity, minHeight: 32)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 0.15)) {
                                    selectedDay = day
                                }
                            }

                        } else {
                            Color.clear.frame(maxWidth: .infinity, minHeight: 32)
                        }
                    }
                }
                .padding(.top, 8)
                .padding(.horizontal, 24)

                
                Spacer()
                
                if itemsForSelectedDay.isEmpty {
                    Text(selectedDay == nil ? "No Events" : "No Events")
                        .font(.system(size: 17, weight: .bold))
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.bottom, 200)
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(itemsForSelectedDay) { ev in
                            HStack(alignment: .top, spacing: 12) {
                                RoundedRectangle(cornerRadius: 2)
                                    .fill(Color.purple)
                                    .frame(width: 3, height: 40)
                                    .padding(.top, 0)

                                VStack(alignment: .leading, spacing: 4) {
                                    Text(ev.title)
                                        .foregroundColor(.white)
                                        .font(.system(size: 17, weight: .semibold))

                                    if let loc = ev.location, !loc.isEmpty {
                                        HStack(spacing: 6) {
                                            Image(systemName: "mappin.and.ellipse")
                                                .font(.system(size: 12))
                                                .foregroundColor(.gray)
                                            Text(loc)
                                                .font(.system(size: 14))
                                                .foregroundColor(.gray)
                                        }
                                    }
                                }

                                Spacer()

                                VStack(alignment: .trailing, spacing: 4) {
                                    Text(timeHHmm(ev.date)).foregroundColor(.white)
                                    if let e = ev.end {
                                        Text(timeHHmm(e)).foregroundColor(.gray)
                                    }
                                }
                                .font(.system(size: 14))
                            }
                            .padding(.vertical, 10)
                            .padding(.horizontal, 16)
                            .background(Color.white.opacity(0.06))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private var monthName: String {
        calendar.monthSymbols[month - 1]
    }
    
    private var weekdays: [String] {
        let symbols = calendar.shortWeekdaySymbols
        let shifted = Array(symbols[1...]) + [symbols[0]]
        return shifted.map { String($0.prefix(1)) }        
    }

    
    private var daySlots: [Int?] {
        var slots: [Int?] = []
        
        let components = DateComponents(year: year, month: month, day: 1)
        guard let firstDay = calendar.date(from: components),
              let range = calendar.range(of: .day, in: .month, for: firstDay)
        else { return [] }
        
        let firstWeekday = calendar.component(.weekday, from: firstDay)
        let leadingEmpty = (firstWeekday - calendar.firstWeekday + 7) % 7
        
        slots.append(contentsOf: Array(repeating: nil, count: leadingEmpty))
        for day in range {
            slots.append(day)
        }
        return slots
    }
}

