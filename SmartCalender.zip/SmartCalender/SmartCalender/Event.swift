//
//  Event.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 11/11/25.
//

// Event.swift
import Foundation

struct Event: Identifiable, Hashable {
    let id: UUID
    var title: String
    var date: Date              
    var end: Date? = nil
    var location: String? = nil

    init(id: UUID = UUID(), title: String, date: Date, end: Date? = nil, location: String? = nil) {
        self.id = id
        self.title = title
        self.date = date
        self.end = end
        self.location = location
    }
}


