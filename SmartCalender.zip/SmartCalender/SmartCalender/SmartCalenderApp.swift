//
//  SmartCalenderApp.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 09/11/25.
//

import SwiftUI

@main
struct SmartCalenderApp: App {
    @StateObject private var eventStore = EventStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(eventStore)
        }
    }
}



