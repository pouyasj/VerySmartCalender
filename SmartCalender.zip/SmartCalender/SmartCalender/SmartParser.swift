//
//  SmartParser.swift
//  SmartCalender
//
//  Created by Pouya Sanjari on 12/11/25.
//

import Foundation

struct SmartParseResult {
    var title: String
    var start: Date
    var end: Date?
    var location: String?
}

enum SmartParser {
    static func parse(_ text: String, baseDay: Date) -> SmartParseResult? {
        let raw = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return nil }

        let lower = raw.lowercased()

        // MARK: 1) Time detection
        let timeRangeRegexes = [
            #"at\s+([0-9:amp\s]+)\s+(until|to|-)\s+([0-9:amp\s]+)"#,
            #"from\s+([0-9:amp\s]+)\s+(to|-)\s+([0-9:amp\s]+)"#,
            #"([0-9]{1,2}(:[0-9]{2})?\s*(am|pm)?)\s*-\s*([0-9]{1,2}(:[0-9]{2})?\s*(am|pm)?)"#
        ]

        var startTimeStr: String?
        var endTimeStr: String?

        for pattern in timeRangeRegexes {
            if let (a, b) = captureTwo(lower, pattern: pattern) {
                startTimeStr = a
                endTimeStr = b
                break
            }
        }

        if startTimeStr == nil {
            if let single = captureOne(lower, pattern: #"at\s+([0-9:amp\s]+)"#) {
                startTimeStr = single
            } else if let single2 = captureOne(lower, pattern: #"([0-9]{1,2}(:[0-9]{2})?\s*(am|pm))"#) {
                startTimeStr = single2
            }
        }

        // MARK: 2) Location (tail after at/@/in)
        let rawLocTail = captureOne(raw, pattern: #"(?:\s(?:at|@|in)\s+)(.+)$"#)

        var location: String? = nil
        if var locTail = rawLocTail {
            // remove any time fragments from location tail
            if let s = startTimeStr {
                locTail = locTail.replacingOccurrences(of: s, with: "", options: .caseInsensitive)
            }
            if let e = endTimeStr {
                locTail = locTail.replacingOccurrences(of: e, with: "", options: .caseInsensitive)
            }

            locTail = locTail
                .replacingOccurrences(of: #"(\bat\b|\buntil\b|\bto\b|\bfrom\b|\b@\b|\bin\b)"#,
                                      with: "",
                                      options: .regularExpression)
                .replacingOccurrences(of: "  ", with: " ")
                .trimmingCharacters(in: .whitespacesAndNewlines)

            if !locTail.isEmpty {
                location = locTail
            }
        }

        // MARK: 3) Title = raw minus time & location
        var title = raw

        if let s = startTimeStr {
            title = title.replacingOccurrences(of: s, with: "", options: .caseInsensitive)
        }
        if let e = endTimeStr {
            title = title.replacingOccurrences(of: e, with: "", options: .caseInsensitive)
        }

        if let loc = location {
            title = title.replacingOccurrences(of: loc, with: "", options: .caseInsensitive)
        }

        if let tail = rawLocTail {
            let candidates = [
                " in \(tail)",
                " at \(tail)",
                " @ \(tail)",
                "in \(tail)",
                "at \(tail)",
                "@ \(tail)"
            ]
            for c in candidates {
                title = title.replacingOccurrences(of: c, with: "", options: .caseInsensitive)
            }
        }


        title = title
            .replacingOccurrences(of: #"(\bat\b|\buntil\b|\bto\b|\bfrom\b|\b@\b|\bin\b)"#,
                                  with: "",
                                  options: .regularExpression)
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        if title.isEmpty {
            title = "New Event"
        }
        // MARK: 4) Build dates
        guard let start = parseTime(startTimeStr, baseDay: baseDay) else { return nil }
        let end = parseTime(endTimeStr, baseDay: baseDay) ?? start.addingTimeInterval(60 * 60)

        return SmartParseResult(
            title: title,
            start: start,
            end: end,
            location: location
        )
    }

    // MARK: - Helpers

    private static func captureTwo(_ text: String, pattern: String) -> (String, String)? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let m = re.firstMatch(in: text, options: [], range: range) else { return nil }
        guard m.numberOfRanges >= 3,
              let r1 = Range(m.range(at: 1), in: text),
              let r2 = Range(m.range(at: 3), in: text) else { return nil }

        let a = String(text[r1]).trimmingCharacters(in: .whitespaces)
        let b = String(text[r2]).trimmingCharacters(in: .whitespaces)
        return (a, b)
    }

    private static func captureOne(_ text: String, pattern: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let m = re.firstMatch(in: text, options: [], range: range),
              m.numberOfRanges >= 2,
              let r1 = Range(m.range(at: 1), in: text) else { return nil }

        return String(text[r1]).trimmingCharacters(in: .whitespaces)
    }

    private static func parseTime(_ t: String?, baseDay: Date) -> Date? {
        guard let t else { return nil }

        // 12h with am/pm
        let f1 = DateFormatter(); f1.dateFormat = "h:mma"; f1.amSymbol = "am"; f1.pmSymbol = "pm"
        let f2 = DateFormatter(); f2.dateFormat = "ha";    f2.amSymbol = "am"; f2.pmSymbol = "pm"
        // 24h
        let f3 = DateFormatter(); f3.dateFormat = "H:mm"
        let f4 = DateFormatter(); f4.dateFormat = "H"

        let trimmed = t
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: ".", with: ":")

        let onlyTime: Date? =
            f1.date(from: trimmed) ??
            f2.date(from: trimmed) ??
            f3.date(from: trimmed) ??
            f4.date(from: trimmed)

        guard let time = onlyTime else { return nil }

        let cal = Calendar.current
        let comps = cal.dateComponents([.year, .month, .day], from: baseDay)
        let hour = cal.component(.hour, from: time)
        let minute = cal.component(.minute, from: time)

        return cal.date(from: DateComponents(
            year: comps.year,
            month: comps.month,
            day: comps.day,
            hour: hour,
            minute: minute
        ))
    }
}
